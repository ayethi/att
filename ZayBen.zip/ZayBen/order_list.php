<?php
	require('backend_header.php');
	require('db_connect.php');
?>

	<h1 class="h3 mb-2 text-gray-800"><i class="fas fa-utensils"></i>Orders</h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4 my-5">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-danger">Orders list</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Voucher No</th>
                      <th>Order Date</th>
                      <th>Total</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  
                  <tbody>

                    <?php

                  

                  $sql="SELECT * FROM orders";
                      $data=$pdo->prepare($sql);
                      $data->execute();
                      $rows=$data->fetchAll();
                      $j=1;
                    foreach ($rows as $his) {
                          $o_date=$his['order_date'];
                          $Voucher=$his['voucher_no'];                         
                          $status=$his['status']."<br>";
                          $total=$his['total']."<br>";


                        
                    ?>

                    <tr>
                      <td><?php echo $j++ ?></td>
                      <td><a class="text-primary" href="orderdetails.php?voucher_no=<?php echo $Voucher ?>"><?php echo $Voucher ?></a></td>
                      <td><?php echo $o_date ?></td>
                      <td><?php echo $total ?></td>
                      <td><a class="text-danger"><?php echo $status ?></a></td>
                      <td><a href="order_confirm.php?v_no=<?php echo $Voucher ?>"><button class="btn btn-success">
                      			<i class="fas fa-check-double"></i>Confirm
                      		</button></a>	

                      		<a href="delivered.php?v_no=<?php echo $Voucher ?>"><button class="btn btn-info">
                      			<i class="fas fa-truck"></i>Delivery
                      		</button></a>

                      </td>
                      
                     
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

<?php
	require('backend_footer.php');
?>