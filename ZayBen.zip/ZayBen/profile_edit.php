<?php
session_start();
require('db_connect.php');

$id=$_POST['update_id'];
$old_photo=$_POST['old_photo'];
$user_name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$new_photo=$_FILES['new_photo'];

	if ($new_photo['name']) {
		$file_path="image/item/".$new_photo['name'];
		move_uploaded_file($new_photo['tmp_name'], $file_path);

	}
	else{
		$file_path=$old_photo;
	}

	$sql="UPDATE users SET user_name=:name,email=:email,photo=:photo,phone=:phone,address=:address WHERE id=:id";
	$data=$pdo->prepare($sql);
	$data->bindparam(':id',$id);
	$data->bindparam(':name',$user_name);
	$data->bindparam(':email',$email);
	$data->bindparam(':phone',$phone);
	$data->bindparam(':address',$address);
	$data->bindparam(':photo',$file_path);
	$data->execute();
	if ($data->rowCount()) {
		header("location:logout.php");
	}
	else{
		echo "error";
	}



?>