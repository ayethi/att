-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 16, 2019 at 02:52 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Zay_Ben`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Appetizer'),
(2, 'Salad');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `item_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `item_name`, `price`, `photo`, `description`, `category_id`) VALUES
(1, 'Caesar Saladss', 740000, 'image/item/menu17.jpg', 'No Description', 1),
(2, 'item 1', 1000, 'image/item/menu2.jpg', 'NO Description', 2),
(3, 'Item 2', 3000, 'image/item/menu3.jpg', 'No Desc', 2),
(4, 'item 3', 4000, 'image/item/menu3.jpg', 'no', 1),
(5, 'item 4', 8000, 'image/item/menu4.jpg', 'No', 1),
(6, 'item 5', 4000, 'image/item/menu6.jpg', 'No', 2),
(7, 'item 7', 800, 'image/item/menu8.jpg', 'no', 2),
(8, 'item8', 3000, 'image/item/menu9.jpg', 'no', 1),
(9, 'item 9', 900, 'image/item/menu10.jpg', 'no', 1),
(12, 'coca cola', 1000, 'image/item/menu14.jpg', 'no', 1),
(13, 'coca', 1200, 'image/item/menu15.jpg', 'no', 1),
(14, 'water', 400, 'image/item/menu16.jpg', 'no', 1),
(15, 'water bottle', 500, 'image/item/menu17.jpg', 'no', 2),
(17, 'salad', 5000, 'image/item/vegetable-sandwich-on-plate-1095550.jpg', 'test description', 2),
(18, 'Humburger', 3000, 'image/item/menu10.jpg', 'With cheese, chicken', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `voucher_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` int(11) NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_date`, `voucher_no`, `total`, `note`, `user_id`, `status`) VALUES
(1, '2019-12-13', '1576183647', 1480000, 'hee heee', 2, 'order'),
(2, '2019-12-13', '1576184320', 1480000, 'notes', 2, 'order'),
(4, '2019-12-15', '1576378080', 744000, '', 2, 'Confirm'),
(5, '2019-12-15', '1576380218', 12000, '', 2, 'Confirm'),
(6, '2019-12-15', '1576382756', 12000, '', 2, 'order'),
(7, '2019-12-15', '1576349870', 8000, '', 4, 'Delivered'),
(8, '2019-12-15', '1576350679', 9000, '', 4, 'order');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `voucher_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `voucher_no`, `item_id`, `qty`) VALUES
(1, '1576183621', 1, 2),
(2, '1576183647', 1, 2),
(3, '1576184320', 1, 2),
(4, '1576186017', 2, 2),
(5, '1576378080', 2, 1),
(6, '1576378080', 1, 1),
(7, '1576378080', 3, 1),
(8, '1576380218', 2, 1),
(9, '1576380218', 3, 1),
(10, '1576380218', 5, 1),
(11, '1576382756', 6, 1),
(12, '1576382756', 5, 1),
(13, '1576349870', 2, 1),
(14, '1576349870', 3, 1),
(15, '1576349870', 6, 1),
(16, '1576350679', 18, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `email`, `password`, `photo`, `phone`, `address`, `role`) VALUES
(1, 'kyaw', 'kyaw@gmail.com', '123', 'image/user/white-cream-on-white-bowl-1633525.jpg', '09692218102', 'yangon', 'admin'),
(2, 'kyaw thi ha lin', 'oo@gmail.com', '123', 'image/item/menu14.jpg', '09692218102', 'Yangon', 'member'),
(4, 'may thu', 'may@gmail.com', '123', 'image/user/menu5.jpg', '09450064872', 'YGN', 'member');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
