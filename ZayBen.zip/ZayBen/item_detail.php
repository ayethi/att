<?php  require('backend_header.php');

require("db_connect.php");
$e_id=$_GET['detail_id'];

	$sql="SELECT items.*,categories.name as cname, categories.id as cid FROM items INNER JOIN categories ON categories.id=items.category_id WHERE items.id=:id";
	$data=$pdo->prepare($sql);
	$data->bindParam(':id',$e_id);
	$data->execute();
	$row=$data->fetch(PDO::FETCH_ASSOC);

	




 ?>



<div class="card shadow">
		<div class="card-header">
			<h2 class="text-danger font-weight-bold"><?php echo $row['item_name'] ?></h2>
			
		</div>
		<div class="card-body">
			<form action="update_item.php" method="POST" enctype="multipart/form-data">
				<div class="row">
							<div class="col-lg-6">
								<img src="<?php echo $row['photo'] ?>" class="py-3 w-100 h-100">
							</div>
							<div class="col-lg-3">
								<h3 class=" font-weight-bold my-2"><?php echo $row['cname'] ?></h3>
								<h3 class="text-danger font-weight-bold py-3"><?php echo $row['price']?></h3>
								
							</div>
						</div>	
			
		</div>
	
	</div>

<?php require ('backend_footer.php');?>