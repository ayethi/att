<?php
	
	require('backend_header.php');
	require 'db_connect.php';

?>

<h1 class="h3 mb-2 text-gray-800"><i class="fas fa-utensils"></i>User</h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
          	
            <div class="card-header py-3">
            	<div class="row">
          			<div class="col-lg-9">
          				 <h5 class="m-0 font-weight-bold text-danger">Customer Lists</h5>
          			</div>
          		</div>
             
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                    
                      <th>Name</th>
                      <th>Email</th>
                     
                      <th>PhoneNo</th>
                   
                      <th>role</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                
                  <tbody>
                    <?php

                      $sql="SELECT * FROM users";
                      $data=$pdo->prepare($sql);
                      $data->execute();
                      $rows=$data->fetchAll();
                      $i=1;
                  
                      foreach ($rows as $items) {
                          $id=$items['id'];
                          $name=$items['user_name'];
                          $email=$items['email'];
                          $password=$items['password'];
                     
                          $phone=$items['phone'];
                          $address=$items['address'];
                          $role=$items['role'];


                     
                    ?>
                    <tr>
                  
                      <td><?php echo $name ?></td>
                      <td><?php echo $email ?></td>
                     
                      <td><?php echo $phone ?></td>
                
                      <td><?php echo $role ?></td>
                      <td> 
					       
                
                       <a href="user_delete.php?de_id=<?php echo $id ?>"><button type="submit" class="btn btn-danger"  style="width:100px" onclick="return confirm('Are you sure want to delete?')"><i class="far fa-trash-alt"></i>Delete</button></a></td>
                     
                    </tr>
                    <?php }  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

<?php
	
	require('backend_footer.php');

?>