<?php 
	require('frontend_header.php');	
 ?>
  <div class="my-5">
  	<h1 style="text-align: center" class="my-5">Your Shopping Cart</h1>
	<hr style="width: 40%">
	<h6 class="text-center">Thank you for your shopping with us</h6>
	
  </div>
	<div class="row">
		<div class="col-lg-8">
			
		</div>
		<div class="col-lg-4">
			<a href="index.php"><button class="btn btn-outline-success my-5"><i class="fas fa-cart-arrow-down"></i>Continue Shopping</button></a>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
				<table class="table">
					<thead>
						<tr>
							<th scope="col">No</th>
							<th scope="col">Item Name</th>						
							<th scope="col">Photo</th>
						
							<th scope="col">Qty</th>
							<th scope="col">Price</th>
							<th scope="col">Total</th>
							<th scope="col">Remove</th>
							
						</tr>
					</thead>
				<tbody id="Tbody">

				</tbody>
				</table>
		</div>
	</div>

	<div class="row mx-5">
		<div class="col-lg-8">
			<form>
				<div class="mb-3">
				<label for="validationTextarea"></label>
				<textarea class="form-control" id="notes" placeholder="Comment...." required></textarea>
				<div >
				
				</div>
				</div>
			</form>
		</div>
	<div class="col-lg-4">
		<a href="#"><button class="btn btn-success my-5 w-50 btnorder" id="Check_out"><i class="fas fa-cash-register"></i>Check out</button></a>
	</div>
	</div>

	

<?php

	require('frontend_footer.php');

?>