<?php  require('backend_header.php');

require("db_connect.php");
$e_id=$_GET['e_id'];

$sql="SELECT * FROM items WHERE id=:id";
$data=$pdo->prepare($sql);
$data->bindParam(':id',$e_id);
$data->execute();
$row=$data->fetch(PDO::FETCH_ASSOC);




 ?>



<div class="card shadow">
		<div class="card-header">
			<h2>Add New Item</h2>
		</div>
		<div class="card-body">
			<form action="update_item.php" method="POST" enctype="multipart/form-data">
				<input type="hidden" name="update_id" value="<?php echo $row['id'] ?>">
				<input type="hidden" name="old_photo" value="<?php echo $row['photo'] ?>">
				<div class="row form-group">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-2 col-2">Item Photo</label>
					<div class="col-lg-10 col-md-10 col-sm-10 col-10">
						
						<nav>
							<div class="nav nav-tabs" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Profile</a>
								<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">New Profile</a>

							</div>
						</nav>
						<div class="tab-content" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
								<img src="<?php echo $row['photo'] ?>" class="py-3 w-25 h-25">
							</div>
							<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
								<input type="file" name="new_photo" class="form-control-file small" id="choosePhoto">
							</div>

						</div>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-2 col-2">Item Name</label>
					<div class="col-lg-10 col-md-10 col-sm-10 col-10">
						<input type="text" name="item_name" class="form-control" id="itemName" placeholder="Enter Item Name" value="<?php echo $row['item_name'] ?>">
					</div>
				</div>
				<div class="row form-group">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-2 col-2">Price</label>
					<div class="col-lg-10 col-md-10 col-sm-10 col-10">
						<input type="text" name="item_price" class="form-control" id="itemPrice" placeholder="Enter Item Price" value="<?php echo $row['price'] ?>">
					</div>
				</div>
				<div class="row form-group">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-2 col-2">Category</label>
					<div class="col-lg-10 col-md-10 col-sm-10 col-10">
						<select class="form-control" name="categoryid">
							<?php
						$sql="SELECT * FROM categories";
						 $data=$pdo->prepare($sql);
                      	$data->execute();
                      	$rows=$data->fetchAll();

                  
                      foreach ($rows as $Category) {
                      	$id=$Category['id'];
                  	   $name=$Category['name'];
					?>
					<option value="<?php echo $id ?>"
						<?php

							if ($row['category_id']==$id) {
								echo "selected";
							}

						?>
						><?php echo $name ?></option>

				<?php } ?>
						</select>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-2 col-2">Description</label>
					<div class="col-lg-10 col-md-10 col-sm-10 col-10">
						<textarea class="form-control" name="item_desc" id="description" placeholder="Description" rows="5"><?php echo $row['description'] ?></textarea>
					</div>
				</div>
				
		
			
		</div>
		<div class="card-footer">
			<div class="row ">
				<div class="col-lg-7">
					
				</div>
				<div class="col-lg-5 text-right">
					<button class="btn btn-secondary" type="reset">Cancel</button>
					<button type="submit" class="btn btn-secondary" type="submit">Save Change</button>
				</div>
			</div>		
		</div>
			</form>
	</div>

<?php require ('backend_footer.php');?>