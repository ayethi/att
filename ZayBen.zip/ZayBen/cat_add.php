<?php

	require("db_connect.php");
	$cat_name=$_POST['cat_name'];
	$sql="INSERT INTO categories (name) VALUES (:category)";
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':category',$cat_name);
	$stmt->execute();

	if ($stmt->rowCount()) {
		header("location:Category_list.php");
	}
	else{
		echo "error";
	}

?>