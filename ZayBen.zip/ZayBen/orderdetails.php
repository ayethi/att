<?php  
	
	require('backend_header.php');

	require('db_connect.php');


	$id=$_GET['voucher_no'];
	


	// $sql = "SELECT * FROM users INNER JOIN orders ON users.id=orders.user_id INNER JOIN order_details ON orders.voucher_no=order_details.voucher_no";

	$sql ="SELECT users.*,orders.voucher_no as v_no,orders.order_date as o_date FROM users INNER JOIN orders ON orders.voucher_no=:id WHERE orders.user_id=users.id";
	//$sql="SELECT orders.* orde"
	/*$sql = "SELECT orders.*, orderdetails.voucherno as cvoucherno FROM orders INNER JOIN orderdetails ON orderdetails.id = orders.id INNER JOIN users ON users.id=orders.user_id";
*/



	$stmt=$pdo->prepare($sql);
	$stmt->bindParam(':id',$id);
	$stmt->execute();
	$row=$stmt->fetch(PDO::FETCH_ASSOC);//select all data from item table ==id

	
 ?>

<div class="container">
	
	<h2>Order Detail</h2>

	<div class="card shadow">
		
		<div class="card-header">
			<h5><?php echo $row['v_no']?> </h5>
		</div>

		<div class="card-body">
			<div class="row">
				<div class="col">
					<button class="btn btn-block btn-dark">
						Invoice
					</button>
				</div>
			</div>
			<!-- /////2nd part -->
			<div class="row">
				<div class="col">
					<p>Zay Ben Restaurant</p>
					<p>No.330, Ahlone Road, Dagon Township, Yangon</p>
					<p>International Hotel Compound</p>
					<p>Phone:(+95) 252 221 114</p>
				</div>
				<div class="col">
					<h1>Zay Ben Restaurant</h1>
				</div>
			</div>
			<!-- ////end of 2nd part -->

			<!-- ////third part -->
			<div class="row">
				<div class="col-lg-6">
					<p><label>Name:</label> <?php echo $row['user_name']?></p>
					<p><label>Phone:</label> <?php echo $row['phone']?></p>
					<p><label>Address:</label> <?php echo $row['address']?></p>
				</div>
			
				<div class="col-lg-6">
					<div class="table-responsive">

						<table class="table table-bordered">
							
							<tbody>
								<tr>
									<td>Invoice</td>
									<td><?php echo $row['v_no']?></td>
								</tr>
								<tr>
									<td>Date</td>
									<td><?php echo $row['o_date']?></td>
								</tr>
							</tbody>	

						</table>
					</div>
				</div>
			</div>
			<!-- ////end of third part -->

			<!-- ////fourth part -->
			<div class="row">
				<div class="table-responsive">
					<table class="table table-bordered">
						<tr>
							<th>No</th>
							<th>Menu</th>
							<th>Unit Price</th>
							<th>Quantity</th>
							<th>Price</th>
						</tr>
				
				
					<tbody>
					<?php


	                 $sql="SELECT items.*,order_details.item_id as item_id,order_details.qty as qty FROM items INNER JOIN order_details ON order_details.voucher_no=:voucher WHERE order_details.item_id=items.id";

                      $data=$pdo->prepare($sql);
                      $data->bindParam(':voucher',$id);
                      $data->execute();
                      $rows=$data->fetchAll();
                      $j=1;
                    foreach ($rows as $his) {
                           $name=$his['item_name']."<br>";
                           $Voucher=$his['price']."<br>";
                           $qty=$his['qty']."<br>";
                           $total=(int)$qty*(int)$Voucher;
                        
                   
                    ?>
                     <tr>
                      <td><?php echo $j++ ?></td>
                      <td><?php echo $name ?></td>
                      <td><?php echo $Voucher ?></td>
                      <td><?php echo $qty ?></td>
                     <td><?php echo $total ?></td>
                    </tr>
                    <?php } ?>
					</tbody>
						</table>
				</div>
			</div>

						
						
						

		</div>
	</div>
</div>












			


				

<?php require ('backend_footer.php');?>