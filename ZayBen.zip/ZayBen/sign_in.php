<?php
	
	require('db_connect.php');
	$email=$_POST['email'];
	$passw=$_POST['password'];
	// echo $email.$passw;

	$sql="SELECT * FROM users WHERE email=:email AND password=:password";
	$data=$pdo->prepare($sql);
	$data->bindParam(':email',$email);
	$data->bindParam(':password',$passw);
	$data->execute();

	session_start();

	if($data->rowCount()<=0)

	{
		if (!isset($_COOKIE['login_count'])) {
			$login_count=1;
		}
		else{
			$login_count=$_COOKIE['login_count'];
			$login_count++;
		}
		setcookie('login_count', $login_count, time()+100);

		if ($login_count>=3) {
			header("location:login_fail.php");
		}
		else{
			//invalid email and password
			$_SESSION['login_reject']="Email and password are not invalid";
			header("location:login.php");				
		}

	}
	else
	{
		$rows= $data->fetch(PDO::FETCH_ASSOC);
		// var_dump($rows);
		$_SESSION['login_user']=$rows;

		if($rows['role']=="admin"){
			header("location:Dashboard.php");
		}
		else
		{
			header("location:index.php");
		}

	}

?>