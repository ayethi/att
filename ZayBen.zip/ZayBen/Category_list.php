<?php
  require("backend_header.php");
  require("db_connect.php");
?> 
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800"><i class="fas fa-hamburger"></i>Category</h1>

          <div class="card" >

            <form action="cat_add.php" method="POST">
              
            
            <div class="card-body">
              <h5 class="card-title text-primary font-weight-bold">Add New Category</h5>
              <div class="row">
                <div class="col-lg-9">
                   <div class="form-group">
                
                <input type="text" name="cat_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                </div>
                <div class="col-lg-3 text-center">
                  <button type="submit" class="btn btn-primary">
                    <i class="far fa-save"></i>Save Changes
                  </button>
                  
                </div>
              </div>
                
               
             
            </div>
            
            </form>
          </div>


         
          <!-- DataTales Example -->
          <div class="card shadow mb-4 my-5">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Category List</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Name</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  
                  <tbody>
                    <?php

                      $sql="SELECT * FROM categories";
                      $data=$pdo->prepare($sql);
                      $data->execute();
                      $rows=$data->fetchAll();

                  
                      foreach ($rows as $Category) {
                          $id=$Category['id'];
                          $name=$Category['name'];

                     
                    ?>

                    <tr>
                      <td><?php echo $id ?></td>
                      <td><?php echo $name ?></td>
                      <td> <button type="submit" class="btn btn-warning mr-2"><i class="far fa-edit"></i>Edit</button>
                       <a href="Cat_delete.php?d_id=<?php echo $id ?>"><button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete?')"><i class="far fa-trash-alt"></i>Delete</button></td></a>
                     
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
<?php
  require("backend_footer.php");
?> 