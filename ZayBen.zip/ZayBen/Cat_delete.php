<?php

require("db_connect.php");
$delete_id=$_REQUEST['d_id'];
$sql="DELETE FROM categories WHERE id=:id";

	$stmt=$pdo->prepare($sql);
	$stmt->bindParam(':id',$delete_id);
	$stmt->execute();

	if ($stmt->rowCount()) {
		header("location:Category_list.php");
	}
	else{
		echo "error";
	}

?>