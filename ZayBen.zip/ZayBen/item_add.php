<?php

	require("db_connect.php");

	$name=$_POST['name'];
	$price=$_POST['price'];
	$Cat_id=$_POST['categoryid'];
	$desc=$_POST['desc'];

	$photo=$_FILES['image'];

	$source_dir="image/item/";
	
	$file_path=$source_dir.$photo['name'];
	
	move_uploaded_file($photo['tmp_name'], $file_path);

	$sql="INSERT INTO items (item_name,price,photo,description,category_id) VALUES (:name,:price,:photo,:description,:cat_id)";
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':name',$name);
	$stmt->bindParam(':price',$price);
	$stmt->bindParam(':photo',$file_path);
	$stmt->bindParam(':description',$desc);
	$stmt->bindParam(':cat_id',$Cat_id);
	$stmt->execute();

	if ($stmt->rowCount()) {
		header("location:Itemlist.php");
	}
	else{
		echo "error";
	}



?>