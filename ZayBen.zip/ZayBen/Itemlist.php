<?php

require ('db_connect.php');
require('backend_header.php');




?>


	<h1 class="h3 mb-2 text-gray-800"><i class="fas fa-utensils"></i>Item</h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
          	
            <div class="card-header py-3">
            	<div class="row">
          			<div class="col-lg-9">
          				 <h5 class="m-0 font-weight-bold text-danger">Item Lists</h5>
          			</div>
          			<div class="col-lg-3 text-right">
                       <a href="ItemNew.php" class="btn btn-primary"><i class="far fa-plus-square"></i>Add New</a>
          			</div>
          		</div>
             
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Name</th>
                      <th>Category</th>
                      <th>Price</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                
                  <tbody>
                    <?php

                      $sql="SELECT items.*,categories.name as cname FROM items INNER JOIN categories ON categories.id=items.category_id";
                      $data=$pdo->prepare($sql);
                      $data->execute();
                      $rows=$data->fetchAll();

                  
                      foreach ($rows as $items) {
                          $id=$items['id'];
                          $name=$items['item_name'];
                          $cat=$items['cname'];
                          $price=$items['price'];


                     
                    ?>
                    <tr>
                      <td><?php echo $id ?></td>
                      <td><?php echo $name ?></td>
                      <td><?php echo $cat ?></td>
                      <td><?php echo $price ?></td>
                      <td> 
					       
                  <a href="item_detail.php?detail_id=<?php echo $id ?>" class="btn btn-primary w-25"><i class="far fa-eye"></i>Details</a>
                      	<a href="item_Edit.php?e_id=<?php echo $id ?>" class="btn btn-warning w-25"><i class="far fa-edit"></i>Edit</a>
                       <a href="item_delete.php?de_id=<?php echo $id ?>"><button type="submit" class="btn btn-danger w-25" onclick="return confirm('Are you sure want to delete?')"><i class="far fa-trash-alt"></i>Delete</button></a></td>
                     
                    </tr>
                    <?php }  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

<?php

require('backend_footer.php');

?>