<?php 

require ('db_connect.php');
require ('frontend_header.php');
?>

 <div class="container">

    <div class="row">

      <div class="col-lg-3">

        <h1 class="my-4">Today Special</h1>
        <div class="list-group">
          <a href="#" class="list-group-item">Appetizer(3)</a>
          <a href="#" class="list-group-item">Beverages(12)</a>
          <a href="#" class="list-group-item">Burger(2)</a>
          <a href="#" class="list-group-item">Dessserts(5)</a>
          <a href="#" class="list-group-item">Main Dishes(2)</a>
          <a href="#" class="list-group-item">One Plate Dishes(3)</a>
          <a href="#" class="list-group-item">Pizza(1)</a>
          <a href="#" class="list-group-item">Salad(2)</a>
          <a href="#" class="list-group-item">Side Dishes(3)</a>
          <a href="#" class="list-group-item">Soups(2)</a>
          <a href="#" class="list-group-item">Vegetables(0)</a>
                  
        </div>

      </div>
 <div class="col-lg-9">

        <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
              <img class="d-block img-fluid w-100 " src="image/item/food1.jpg" alt="First slide" style="height: 400px">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid w-100" src="image/item/slide2.jpg" alt="Second slide" style="height: 400px">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid w-100" src="image/item/slide3.jpg" alt="Third slide" style="height: 400px"> 
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
         <div class="row">
          <?php
           $sql="SELECT * FROM items";
                      $data=$pdo->prepare($sql);
                      $data->execute();
                      $rows=$data->fetchAll();

                  
                      foreach ($rows as $items) {
                          $item_id=$items['id'];
                          $item_name=$items['item_name'];
                          $price=$items['price'];
                          $photo=$items['photo'];
                        
                     
                    ?>
       
         
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top my_img" src="<?php echo $photo ?>" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#" class="font-weight-bold text-dark"><?php echo $item_name ?></a>
                </h4>
              </div>
              <div class="card-footer">
              	<div class="row">
              		<div class="col-lg-3">
                		<i class="fas fa-tags text-danger"><?php echo $price ?></i>              			
              		</div>
                  <?php

                    if (isset($_SESSION['login_user'])) {
                      ?>
                        
                  <div class="col-lg-9 text-right">
                   <button class="btn btn-secondary btn-sm btn_atc" data-id="<?php echo $item_id ?>" data-name="<?php echo $item_name ?>" data-price="<?php echo $price ?>" data-photo="<?php echo $photo ?>"><i class="fas fa-cart-arrow-down"></i>Add to cart</button>
                  </div>  
                  <?php
                    }else{

                      ?>
 


                   <div class="col-lg-9 text-right">
                   <button class="btn btn-secondary btn-sm btn_atc" data-id="<?php echo $item_id ?>" data-name="<?php echo $item_name ?>" data-price="<?php echo $price ?>" data-photo="<?php echo $photo ?>" disabled><i class="fas fa-cart-arrow-down"></i>Add to Cart</button>
                  </div>   

                      <?php
                    }

                  ?>
              		
              	</div>

              </div>
            </div>
          </div>
        <?php } ?>

        </div>
        
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->



<?php  require ('frontend_footer.php');?>