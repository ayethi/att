<?php
	require('db_connect.php');
	$new_pass=$_POST['password'];
	$update_id=$_POST['update_id'];

	$sql="UPDATE users SET password=:password WHERE id=:id";
	$data=$pdo->prepare($sql);

	$data->bindparam(':id',$update_id);
	$data->bindparam(':password',$new_pass);

	$data->execute();
	if ($data->rowCount()) {
		header("location:logout.php");
	}
	else{
		echo "error";
	}
?>