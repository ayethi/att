<?php

	require("db_connect.php");
	$id=$_REQUEST['de_id'];
	$sql="DELETE FROM items WHERE id=:id";

	$stmt=$pdo->prepare($sql);
	$stmt->bindParam(':id',$id);
	$stmt->execute();

	if ($stmt->rowCount()) {
		header("location:Itemlist.php");
	}
	else{
		echo "error";
	}



?>