<?php

	require('frontend_header.php');
  require('db_connect.php');

?>

	 <h1 class="text-center text-success my-5">Your Order History</h1>
	          <!-- DataTales Example -->
          <div class="card shadow mb-4 my-5">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-success text-center">Order History list</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Voucher No</th>
                      <th>Order Date</th>
                      <th>Item Name</th>
                      <th>Photo</th>
                      <th>Price</th>
                      <th>Qty</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  
                  <tbody>

                    <?php

                    $id=$_SESSION['login_user']['id'];

                  $sql="SELECT orders.*,order_details.item_id as item_id,order_details.qty as qty FROM orders INNER JOIN order_details ON orders.voucher_no=order_details.voucher_no WHERE orders.user_id=:id";

                      $data=$pdo->prepare($sql);
                      $data->bindParam(':id',$id);
                      $data->execute();
                      $rows=$data->fetchAll();
                      $j=1;
                    foreach ($rows as $his) {
                          $o_date=$his['order_date']."<br>";
                          $Voucher=$his['voucher_no']."<br>";
                          $item_id=$his['item_id']."<br>";
                          $qty=$his['qty']."<br>";
                          $total=$his['total']."<br>";

                          $sql="SELECT * FROM items WHERE id=:id";
                          $data=$pdo->prepare($sql);
                          $data->bindParam(':id',$item_id);
                          $data->execute();
                          $row=$data->fetch(PDO::FETCH_ASSOC);

                        
                    ?>

                    <tr>
                      <td><?php echo $j++ ?></td>
                      <td><?php echo $Voucher ?></td>
                      <td><?php echo $o_date ?></td>
                      <td><?php echo $row['item_name'] ?></td>
                      <td><img src="<?php echo $row['photo'] ?>" width="100px" height="90px"></td>
                      <td><?php echo $row['price'] ?></td>
                      <td><?php echo $qty ?></td>
                      <td><?php echo $total ?></td>
                      
                     
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>


<?php

	require('frontend_footer.php');

?>