<?php

require("backend_header.php");
require("db_connect.php");
?>

<div class="card">
  <div class="card-header">
    Add New Item
  </div>
  <div class="card-body">
 <form action="item_add.php" method="POST" enctype="multipart/form-data">
 
 	<div class="row">
 		<div class="col-lg-3">
 			<label>Item Photo</label>
 		</div>
 		<div class="col-lg-9">
 			  <div class="form-group">
			    <input type="file" name="image" class="form-control-file small" id="exampleFormControlFile1">
			  </div>
 		</div>
 	</div>

 	 <div class="row">
 		<div class="col-lg-3">
 			<label for="Itemname">Item Name</label>
 		</div>
 		<div class="col-lg-9">
			<div class="form-group">
				<input type="text" name="name" class="form-control" id="Itemname" placeholder="Enter Item Name">
			</div>
 		</div>
 	</div>
 	 	 <div class="row">
 		<div class="col-lg-3">
 			<label for="price">Price</label>
 		</div>
 		<div class="col-lg-9">
			<div class="form-group">
				<input type="text" name="price" class="form-control" id="price" placeholder="Enter Item Price">
			</div>
 		</div>
 	</div> 	 <div class="row">
 		<div class="col-lg-3">
 			<label for="category">Category</label>
 		</div>
 		<div class="col-lg-9">
			<div class="form-group">
				<select id="category" name="categoryid" class="form-control">
					<?php
						$sql="SELECT * FROM categories";
						 $data=$pdo->prepare($sql);
                      	$data->execute();
                      	$rows=$data->fetchAll();

                  
                      foreach ($rows as $Category) {
                      	$id=$Category['id'];
                  	   $name=$Category['name'];
					?>
					<option value="<?php echo $id ?>" selected><?php echo $name ?></option>

				<?php } ?>
				</select>
			</div>
 		</div>
 	</div> 	 <div class="row">
 		<div class="col-lg-3">
 			<label for="description">Description</label>
 		</div>
 		<div class="col-lg-9">
			<div class="form-group">
			    <textarea name="desc" class="form-control" id="description" placeholder="Description" rows="3"></textarea>
			</div>
 		</div>
 	</div>
 	<div class="row">
 		<div class="col-lg-7">
 			
 		</div>
 		<div class="col-lg-5 text-right">
 			 <button type="reset" class="btn btn-secondary"><i class="far fa-window-close"></i>Cancel</button>

 			<button type="submit" class="btn btn-primary"><i class="far fa-save"></i>Save Changes</button>
 		</div>
 	</div>
 	 



 
 
</form>
  </div>
</div>

<?php

require ("backend_footer.php");

?>