

$(document).ready(function () {
	


	function showCount(){

		
		let Cart_String=localStorage.getItem('cart');

		if (Cart_String) {

			let cartArray=JSON.parse(Cart_String);
			let total_qty=0;
			$.each(cartArray,function (i,v) {

				let qty=v.qty;
				total_qty+=qty;

			})			
				let count_item=`
					<a href="cart.php"><button class="btn">
					  <i class="fas fa-cart-arrow-down fa-2x" style="color:white"></i>
					  <span class="badge badge-pill badge-light" style="position: relative;top:-25px;left:-10px">
					  ${total_qty}</span>
					</button></a>
					`;  
			$('.count').html(count_item);	
			

			
		}

	}



	function getData() {

				let Cart_String=localStorage.getItem('cart');
				
				if (Cart_String) {
					let cartArr=JSON.parse(Cart_String);
					let tab='';
					let prices=0;
					
					$.each(cartArr,function (i,v) {
						let name=v.name;
  						let price=v.price;
  						let qty=v.qty;
  						let photo=v.photo;
  						let total=price*qty;
  						prices=total+prices;
  					
  						
  						

  						
  						
  						
					    tab+=`<tr>
						<td>${i+1}</td>

						<td><img src="${photo}" class="img-fluid"
						style="width:100px;height:100px" ></td>
						<td>${name}</td>
						
						<td><input style="height:30px;width:100px" type="number" min="0" class="chg" value="${qty}" data-id="${i}"></td>
						<td>${price}MMK</td>
						<td>${total}</td>
						<td><button data-id="${i}" class="btn btn-danger rounded-circle btn-sm btnDelete">X</button></td>

				 	</tr>`;
					
					})

					let tax =prices*0.05;
					let total_amount = tax+prices;

					let tab1=`
					<tr>
					<td></td>
					</tr>
					<tr>
					<td colspan="3"></td>
					<td class="text-left">Subtotal</td>
					<td colspan="3" class="text-left">${prices}MMK</td></tr>


					<tr>
					<td></td>
					</tr>
					<tr>
					<td colspan="3"></td>
					<td class="text-left">Tax</td>
					<td colspan="3">5%</td></tr>

					<tr>
					<td></td>
					</tr>
					<tr>
					<td colspan="3"></td>
					<td class="text-left text-danger font-weight-bold">Total Amount:</td>
					<td colspan="3" class="text-danger font-weight-bold">${total_amount}MMK</td></tr>

					`;
					$('#Tbody').html(tab+tab1);
					$('#myTB').show();	


					
				}
				else{
					$('#myTB').hide();

				}
	}
	getData();
	showCount();





	$('.btn_atc').click(function () {
		showCount();
		getData();

		let name= $(this).data('name');
		let price=$(this).data('price');
		let Item_id=$(this).data('id');
		let Item_photo=$(this).data('photo');


		let local_cart;

		let qty=1;
		let condition=false;

		let Cart_Str=localStorage.getItem('cart');

		let cart={
				name:name,
				price:price,
				id:Item_id,
				qty:qty,
				photo:Item_photo
			}
		
		if (Cart_Str==null) {
		    local_cart=Array();
		    
		}



		 else{
		

		 	local_cart=JSON.parse(Cart_Str);

			$.each(local_cart,function (i,v) {
					
  						if (Item_id==v.id) {
  							
  							v.qty++;
  							
  							condition=true;
  							localStorage.setItem('cart',JSON.stringify(local_cart));
 							
  						}

  						
					
					})	

			
			
				
		}
		if(condition==false){
			local_cart.push(cart);
			localStorage.setItem('cart',JSON.stringify(local_cart));
		}
		showCount();	
	})

	$('#Tbody').on('change','.chg',function() {
		let id=$(this).data('id');
		let update_qty=$(this).val();

	
		let cartArr;
		let loStr=localStorage.getItem('cart');

				if (loStr) {
					let cartArr=JSON.parse(loStr);
					let price=cartArr[id].price;
					cartArr[id].qty=parseInt(update_qty);

					price=price*update_qty;
					cartArr[id].price=price;
					localStorage.setItem('cart',JSON.stringify(cartArr));
					getData();	
					showCount();
				}

				if (update_qty==0) {

					let loStr=localStorage.getItem('cart');
					if (loStr) {
						let stuArr=JSON.parse(loStr);
						stuArr.splice(id,1);
						localStorage.setItem('cart',JSON.stringify(stuArr));
						getData();
						showCount();
						
				}

				}
	})


	
	$('#Tbody').on('click','.btnDelete',function() {
				let del=confirm('Are you sure');
				if (del) {
					let id=$(this).data('id');
					let loStr=localStorage.getItem('cart');
					if (loStr) {
						let stuArr=JSON.parse(loStr);
						stuArr.splice(id,1);
						localStorage.setItem('cart',JSON.stringify(stuArr));
						getData();	
						showCount();
				}	
				}
	})


	$('.btnorder').on('click',function () {		
	
		var note= $('#notes').val();  
		var cart= localStorage.getItem('cart');
		var cartObj=JSON.parse(cart);

		//var cartArr=cartObj.mycart;
		//ajax
		$.post('store_order.php',{cart: cartObj,note:note},function (respoonse) {
			localStorage.clear();
			window.location.href="order_success.php";
		})

	})
	
})

