
<?php

  require('frontend_header.php');

?>
 <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
           
              <div class="row">

                <div class="offset-4 col-lg-4 d-none d-lg-block">
                  <img src="image/success.jpg" class="img-fluid">
                </div>
            </div>
             <div class="row">
              <div class="col-lg-12">
                  <h2 class="py-3 px-3 text-center text-success">THANK YOU FOR THE ORDER</h2>
                  <h6 class="py-3 px-3 text-center">You have successfully placed your order</h6>
                 
              </div>
            </div>
            <div class="row my-5">
              <div class="col-lg-12 text-center">
                  <a href="index.php"><button class="btn btn-outline-danger btn-sm">View Orders</button></a>
              </div>
            </div>
            
          
          </div>
        </div>

      </div>

    </div>

  </div>

<?php

  require('frontend_footer.php');

?>