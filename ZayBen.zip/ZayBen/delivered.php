<?php

		require('db_connect.php');
		$voucher=$_REQUEST['v_no'];
		$status="Delivered";
		$sql="UPDATE orders set status=:status WHERE voucher_no=:vno";
		$data=$pdo->prepare($sql);
		$data->bindParam(':vno',$voucher);
		$data->bindParam(':status',$status);
		$data->execute();
		header('location:Dashboard.php');
	


?>