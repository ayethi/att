<?php

require('db_connect.php');

$id=$_POST['update_id'];
$old_photo=$_POST['old_photo'];
$item_name=$_POST['item_name'];
$item_price=$_POST['item_price'];
$item_desc=$_POST['item_desc'];
$cat_id=$_POST['categoryid'];
$new_photo=$_FILES['new_photo'];

	if ($new_photo['name']) {
		$file_path="image/item/".$new_photo['name'];
		move_uploaded_file($new_photo['tmp_name'], $file_path);

	}
	else{
		$file_path=$old_photo;
	}

	$sql="UPDATE items SET item_name=:name,price=:price,photo=:photo,description=:description,category_id=:cat_id WHERE id=:id";
	$data=$pdo->prepare($sql);

	$data->bindparam(':id',$id);
	$data->bindparam(':name',$item_name);
	$data->bindparam(':price',$item_price);
	$data->bindparam(':photo',$file_path);
	$data->bindparam(':description',$item_desc);
	$data->bindparam(':cat_id',$cat_id);
	$data->execute();
	if ($data->rowCount()) {
		header("location:Itemlist.php");
	}
	else{
		echo "error";
	}



?>