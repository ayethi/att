<?php

	require('db_connect.php');
	$name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['psw'];
	$c_pass=$_POST['c_psw'];
	$phone=$_POST['phone'];
	$add=$_POST['address'];
	$photo=$_FILES['photo'];
	$role="member";
	$source_dir="image/user/";
	
	$file_path=$source_dir.$photo['name'];
	
	move_uploaded_file($photo['tmp_name'], $file_path);

	if ($password==$c_pass) {
		$sql="INSERT INTO users (user_name,email,password,photo,phone,address,role) VALUES (:name,:email,:password,:photo,:phone,:address,:role)";
	
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':name',$name);
	$stmt->bindParam(':email',$email);
	$stmt->bindParam(':password',$password);
	$stmt->bindParam(':photo',$file_path);
	$stmt->bindParam(':phone',$phone);
	$stmt->bindParam(':address',$add);
	$stmt->bindParam(':role',$role);
	$stmt->execute();

	if ($stmt->rowCount()) {
		header("location:login.php");                                                  
	}
	else{
		echo "error";
	}
	}
	else{
		
		echo "error";
	}

	


?>