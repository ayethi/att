<?php
	
	session_start();
	require('db_connect.php');
	$cartarr=$_POST['cart'];
	$note=$_POST['note'];
	//var_dump($cartarr);die();
	date_default_timezone_set('Asia/Rangoon');
	$voucher=strtotime(date("h:i:s"));
	$todayDate=date('Y-m-d');
	$user_id=$_SESSION['login_user']['id'];
	$status="order";
	$total=0;
	foreach ($cartarr as $key => $value) {
		$id= $value['id'];
		
		$qty=$value['qty'];
		$price=$value['price'];
		$subtotal=$qty*$price;
		$total +=$subtotal ++;
		$order_detail="INSERT INTO order_details (voucher_no,item_id,qty) VALUES (:voucherno,:itemid,:qty)";
		$order_details_data=$pdo->prepare($order_detail);
		$order_details_data->bindParam(':voucherno',$voucher);
		$order_details_data->bindParam(':itemid',$id);
		$order_details_data->bindParam(':qty',$qty);
		$order_details_data->execute();

	}

	$order="INSERT INTO orders (order_date,voucher_no,total,note,user_id,status) VALUES (:orderdate,:voucherno,:total,:note,:user_id,:status)";
		$order_data=$pdo->prepare($order);
		$order_data->bindParam(':orderdate',$todayDate);
		$order_data->bindParam(':voucherno',$voucher);
		$order_data->bindParam(':total',$total);
		$order_data->bindParam(':note',$note);
		$order_data->bindParam(':user_id',$user_id);
		$order_data->bindParam(':status',$status);
		$order_data->execute();

		
?>