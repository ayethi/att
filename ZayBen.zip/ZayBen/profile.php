<?php

	require('frontend_header.php');


?>

<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
           
              <div class="row">

                <div class="offset-1 col-lg-4 d-none d-lg-block">
                  <img src="<?php echo $_SESSION['login_user']['photo'] ?>" class="img-fluid w-75 h-75 rounded-circle mx-3 my-3">
                </div>
                <div class="col-lg-4 mt-5">
                	<h3 class="font-weight-bold pb-5"><?php echo $_SESSION['login_user']['user_name'] ?></h3>
                	<p><i class="fas fa-home"></i>&nbsp;&nbsp;<?php echo $_SESSION['login_user']['address'] ?></p>
                	<p><i class="fas fa-phone-square-alt"></i>&nbsp;&nbsp;<?php echo $_SESSION['login_user']['phone'] ?></p>
                	<p><i class="fas fa-map-marked-alt"></i>&nbsp;&nbsp;<?php echo $_SESSION['login_user']['email'] ?></p>
                </div>
            </div>

            <div class="row mb-3">
            	<div class="offset-lg-5 col-lg-3 text-left">
            		<a href="profile_upload.php" class="btn btn-primary">Profile Uploads</a>
            		
            	</div>
            	<div class="col-3 text-left">
            		<a href="change_passwordform.php" class="btn btn-info">Change Passwords</a>
            	</div>
            </div>
  
          </div>
        </div>

      </div>

    </div>

  </div>
<?php

	require('frontend_footer.php');

?>